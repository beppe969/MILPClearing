# Manifest: paper outputs and reproduction commands

| Paper item | Reference files | Reproduction command |
|---|---|---|
| Table 1 | `results/tables/instance_summary.csv`, `.tex` | `python scripts/check_installation.py` recomputes margins |
| Table 2 | `results/tables/validation_table.csv`, `.tex` | `python scripts/recompute_validation.py` |
| Figure 1 | `results/data/pre_curve.csv`, `results/tables/breakpoint_table.csv` | `python scripts/reproduce_all.py`; grid recompute: `python scripts/recompute_pre_curve.py` |
| Table 3 | `results/tables/breakpoint_table.csv`, `.tex` | reference CSV; validated by pre-curve LP solves |
| Figure 2/Table 4 | `results/tables/salient_growth.csv`, `.tex` | `python scripts/reproduce_all.py` |
| Figure 3/Table 5 | `results/data/post_scalar_curve.csv`, `results/tables/post_slope_decreases.csv`, `.tex` | `python scripts/regenerate_dpost_scalar_exact.py` |
| Figure 4/Table 6 | `results/tables/bounds_table.csv`, `results/data/regime_generation_trace.csv` | `python scripts/reproduce_all.py`; basic recompute: `python scripts/recompute_bounds_mbound.py` |
| Table 7 | `results/tables/regime_trace_table.tex`, `results/data/regime_generation_trace.csv` | reference CSV/TeX |
| Figures 5-7/Tables 8-9 | `results/tables/localized_*`, `results/figures/localized_*` | `python scripts/recompute_localized_certificate.py --instance M-bound --epsilon-over-ub 2 --splits 60` |
| Figure 8/Table 10 | `results/tables/large_scenario_table.csv` | `python scripts/recompute_large_scenario.py` |
| Figure 9/Table 11/Figure 10 | `results/tables/large_localized_bounds_table.csv`, `results/figures/large_localized_*` | `python scripts/recompute_localized_certificate.py --instance L-353 --epsilon-over-ub 1.5 --splits 5` |

The exact manuscript figures can always be regenerated from the reference CSV files by running:

```bash
python scripts/reproduce_all.py
```
