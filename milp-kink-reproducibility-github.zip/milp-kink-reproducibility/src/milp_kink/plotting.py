from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def _ensure(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _save(fig, outdir: Path, stem: str) -> None:
    fig.tight_layout()
    fig.savefig(outdir / f"{stem}.png", dpi=300)
    fig.savefig(outdir / f"{stem}.pdf")
    plt.close(fig)


def plot_pre_insolvency(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    curve = pd.read_csv(results_dir / "data" / "pre_curve.csv")
    breaks = pd.read_csv(results_dir / "tables" / "breakpoint_table.csv")
    eps_star = float(breaks.iloc[0]["epsilon_over_ub"])
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(curve["epsilon_over_ub"], curve["loss_norm"], label="exact LP-dual value")
    ax.axvline(eps_star, linestyle=":", label=r"$\epsilon^*$")
    ax.axvline(1.0, linestyle="--", label=r"$\epsilon_{ub}$")
    ax.scatter(breaks["epsilon_over_ub"], np.interp(breaks["epsilon_over_ub"], curve["epsilon_over_ub"], curve["loss_norm"]), label="salient points")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel(r"$\eta_{wc}(\epsilon)/(\mathbf{1}^\top\bar p)$")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "pre_insolvency_salient_points")


def plot_salient_growth(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    df = pd.read_csv(results_dir / "tables" / "salient_growth.csv")
    grp = df.groupby("n")["salient_points_after_epsilon_star"].agg(["mean", "min", "max"]).reset_index()
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(grp["n"], grp["mean"], marker="o", label="mean")
    ax.fill_between(grp["n"], grp["min"], grp["max"], alpha=0.2, label="range")
    ax.set_xlabel("number of banks n")
    ax.set_ylabel(r"salient points on $(\epsilon^*,\epsilon_{ub})$")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "salient_growth")


def plot_post_scalar(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    curve = pd.read_csv(results_dir / "data" / "post_scalar_curve.csv")
    summary = pd.read_csv(results_dir / "tables" / "instance_summary.csv")
    dpost = summary.loc[summary["Instance"] == "D-post"].iloc[0]
    eps_star_over_ub = float(dpost[r"$\epsilon^*$"]) / float(dpost[r"$\epsilon_{ub}$"])
    slopes = pd.read_csv(results_dir / "tables" / "post_slope_decreases.csv")
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(curve["epsilon_over_ub"], curve["loss_norm"], label="scalar search + exact clearing")
    ax.axvline(eps_star_over_ub, linestyle=":", label=r"$\epsilon^*$")
    ax.axvline(1.0, linestyle="--", label=r"$\epsilon_{ub}$")
    if len(slopes):
        xs = slopes["epsilon_over_ub"].to_numpy()
        ys = np.interp(xs, curve["epsilon_over_ub"], curve["loss_norm"])
        ax.scatter(xs, ys, s=22, label="post-insolvency kinks")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("normalized worst-case loss")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "post_insolvency_scalar_curve")


def plot_bounds_and_regime_generation(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    b = pd.read_csv(results_dir / "tables" / "bounds_table.csv")
    trace = pd.read_csv(results_dir / "data" / "regime_generation_trace.csv")
    trace2 = trace[np.isclose(trace["epsilon_over_ub"], 2.0)]
    fig, axs = plt.subplots(1, 2, figsize=(10.5, 4.0))
    ax = axs[0]
    ax.fill_between(b["epsilon_over_ub"], b["LB_norm"], b["UB_norm"], alpha=0.2, label="certified band")
    ax.plot(b["epsilon_over_ub"], b["LB_norm"], marker="o", label="scenario LB")
    ax.plot(b["epsilon_over_ub"], b["UB_norm"], marker="s", label="fixed-regime UB")
    ax.axvline(1.0, linestyle="--", alpha=0.5)
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("normalized loss")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    ax = axs[1]
    ax.plot(trace2["iteration"], trace2["gap_norm"], marker="o")
    ax.set_xlabel("iteration")
    ax.set_ylabel("normalized gap")
    ax.set_title(r"fixed-regime generation, $\epsilon/\epsilon_{ub}=2.0$")
    ax.grid(True, alpha=0.3)
    _save(fig, outdir, "bounds_and_regime_generation")


def plot_localized_bounds(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    df = pd.read_csv(results_dir / "tables" / "localized_bounds_table.csv")
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(df["epsilon_over_ub"], df["LB_norm"], marker="o", label="scenario LB")
    ax.plot(df["epsilon_over_ub"], df["global_UB_norm"], marker="s", linestyle="--", label="global fixed-regime UB")
    ax.plot(df["epsilon_over_ub"], df["enhanced_UB_norm"], marker="^", label="enhanced UB")
    ax.axvline(1.0, linestyle="--", alpha=0.35)
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("normalized loss")
    ax.set_title("localized fixed-pattern refinement")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "localized_bounds_comparison")


def plot_localized_trace(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    tr = pd.read_csv(results_dir / "tables" / "localized_trace_eps2.csv")
    b = pd.read_csv(results_dir / "tables" / "bounds_table.csv")
    row2 = b.loc[np.isclose(b["epsilon_over_ub"], 2.0)].iloc[0]
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(tr["num_cells"], tr["localized_UB_norm"], marker="o", label="localized UB")
    ax.axhline(row2["UB_norm"], linestyle="--", label="global UB")
    ax.axhline(row2["LB_norm"], linestyle=":", label="scenario LB")
    ax.set_xlabel("number of partition cells")
    ax.set_ylabel("normalized loss")
    ax.set_title(r"adaptive refinement at $\epsilon/\epsilon_{ub}=2$")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "localized_trace_eps2")


def plot_localized_complexity(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    df = pd.read_csv(results_dir / "tables" / "localized_complexity_table.csv")
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(df["num_cells"], df["local_time_s"], marker="o", label="localized UB time")
    ax.plot(df["num_cells"], df["total_time_s"], marker="s", label="with scenario LB")
    ax.set_xlabel("number of final cells")
    ax.set_ylabel("wall-clock seconds")
    ax.set_title("localized certificate computational effort")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "localized_complexity_effort")

    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(df["epsilon_over_ub"], df["num_cells"], marker="o", label="cells")
    ax.plot(df["epsilon_over_ub"], df["local_pattern_clearings"], marker="s", label="local clearings")
    ax.plot(df["epsilon_over_ub"], df["fixed_pattern_lp_evals"], marker="^", label="fixed-pattern LPs")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("count")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "localized_complexity_counts")


def plot_large_scenario(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    df = pd.read_csv(results_dir / "tables" / "large_scenario_table.csv")
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(df["epsilon_over_ub"], df["best_LB_norm"], marker="o", label="scenario lower bound")
    ax.axvline(float(df.iloc[1]["epsilon_over_ub"]), linestyle=":", label=r"$\epsilon^*$")
    ax.axvline(1.0, linestyle="--", label=r"$\epsilon_{ub}$")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("normalized loss lower bound")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "large_scenario_post_insolvency")


def plot_large_localized(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    results_dir = Path(results_dir)
    outdir = _ensure(outdir or results_dir / "figures")
    scen = pd.read_csv(results_dir / "tables" / "large_scenario_table.csv")
    loc = pd.read_csv(results_dir / "tables" / "large_localized_bounds_table.csv")
    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(scen["epsilon_over_ub"], scen["best_LB_norm"], marker="o", label="scenario LB")
    ax.scatter(loc["epsilon_over_ub"], loc["localized_UB_norm"], marker="s", label="localized UB")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("normalized loss")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "large_localized_bounds")

    fig, ax = plt.subplots(figsize=(6.2, 4.0))
    ax.plot(loc["epsilon_over_ub"], loc["cells"], marker="o", label="cells")
    ax.plot(loc["epsilon_over_ub"], loc["local_clearings"], marker="s", label="local clearings")
    ax.plot(loc["epsilon_over_ub"], loc["fixed_pattern_LPs"], marker="^", label="pattern LPs")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("count")
    ax.grid(True, alpha=0.3)
    ax.legend(frameon=False)
    _save(fig, outdir, "large_localized_effort")


def plot_all(results_dir: str | Path = "results", outdir: str | Path | None = None) -> None:
    plot_pre_insolvency(results_dir, outdir)
    plot_salient_growth(results_dir, outdir)
    plot_post_scalar(results_dir, outdir)
    plot_bounds_and_regime_generation(results_dir, outdir)
    plot_localized_bounds(results_dir, outdir)
    plot_localized_trace(results_dir, outdir)
    plot_localized_complexity(results_dir, outdir)
    plot_large_scenario(results_dir, outdir)
    plot_large_localized(results_dir, outdir)
