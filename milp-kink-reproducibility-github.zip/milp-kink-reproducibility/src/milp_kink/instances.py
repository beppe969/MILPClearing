from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List

import numpy as np


@dataclass(frozen=True)
class FinancialNetworkInstance:
    """Container for one numerical financial-network instance.

    Attributes
    ----------
    name:
        Instance name used in the paper, e.g. ``D-pre``.
    Pbar:
        Nominal liability matrix. Entry ``Pbar[i, j]`` is the nominal liability
        of bank i to bank j.
    A:
        Relative-liabilities matrix.
    pbar:
        Total nominal interbank liabilities by bank.
    cbar:
        Nominal external net positions.
    S:
        Common-asset exposure matrix.
    metadata:
        Extra scalar fields stored in the distributed ``.npz`` files.
    """

    name: str
    Pbar: np.ndarray
    A: np.ndarray
    pbar: np.ndarray
    cbar: np.ndarray
    S: np.ndarray
    metadata: Dict[str, Any]

    @property
    def n(self) -> int:
        return int(self.pbar.size)

    @property
    def m(self) -> int:
        return int(self.S.shape[1])

    @property
    def total_liabilities(self) -> float:
        return float(np.sum(self.pbar))

    def c(self, delta: np.ndarray) -> np.ndarray:
        """External net positions under asset-price perturbation ``delta``."""
        delta = np.asarray(delta, dtype=float).reshape(self.m)
        return self.cbar + self.S @ delta


INSTANCE_FILES = {
    "D-val": "D-val.npz",
    "D-pre": "D-pre.npz",
    "M-bound": "M-bound.npz",
    "D-post": "D-post.npz",
    "L-353": "L-353.npz",
}


def _scalar(x: np.ndarray) -> Any:
    try:
        return x.item()
    except Exception:
        return x


def list_instances(data_dir: str | Path = "data") -> List[str]:
    """Return the known paper instance names available in ``data_dir``."""
    data_dir = Path(data_dir)
    return [name for name, fn in INSTANCE_FILES.items() if (data_dir / fn).exists()]


def load_instance(name: str, data_dir: str | Path = "data") -> FinancialNetworkInstance:
    """Load an instance from the distributed ``.npz`` files.

    Parameters
    ----------
    name:
        One of ``D-val``, ``D-pre``, ``M-bound``, ``D-post`` or ``L-353``.
    data_dir:
        Directory containing the ``.npz`` input instances.
    """
    if name not in INSTANCE_FILES:
        raise ValueError(f"Unknown instance {name!r}; known names are {sorted(INSTANCE_FILES)}")
    path = Path(data_dir) / INSTANCE_FILES[name]
    if not path.exists():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=False) as data:
        arrays = {key: data[key] for key in data.files}
    metadata = {
        key: _scalar(value)
        for key, value in arrays.items()
        if key not in {"Pbar", "A", "pbar", "cbar", "S"}
    }
    return FinancialNetworkInstance(
        name=str(metadata.get("name", name)),
        Pbar=np.asarray(arrays["Pbar"], dtype=float),
        A=np.asarray(arrays["A"], dtype=float),
        pbar=np.asarray(arrays["pbar"], dtype=float).reshape(-1),
        cbar=np.asarray(arrays["cbar"], dtype=float).reshape(-1),
        S=np.asarray(arrays["S"], dtype=float),
        metadata=metadata,
    )
