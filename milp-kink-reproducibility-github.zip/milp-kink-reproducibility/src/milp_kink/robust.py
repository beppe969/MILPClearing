from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
from scipy.optimize import linprog

from .instances import FinancialNetworkInstance


@dataclass
class RobustDualResult:
    value: float
    value_norm: float
    asset: int
    epsilon: float
    pbar_total: float
    beta: np.ndarray
    lam: np.ndarray
    success: bool
    message: str = ""

    @property
    def q_label(self) -> str:
        return f"+e{self.asset + 1}"


def row_dual_norms_for_l1(S: np.ndarray) -> np.ndarray:
    """Dual row norms s_i = ||sigma_i||_inf for l1 price perturbations."""
    return np.max(np.abs(S), axis=1)


def epsilon_star(inst: FinancialNetworkInstance) -> float:
    """Default-resilience margin for l1 uncertainty."""
    rbar = inst.cbar + inst.A.T @ inst.pbar - inst.pbar
    s = row_dual_norms_for_l1(inst.S)
    mask = s > 1e-14
    if not np.any(mask):
        return np.inf
    return float(np.min(rbar[mask] / s[mask]))


def epsilon_ub_l1(inst: FinancialNetworkInstance) -> float:
    """Insolvency-resilience margin for l1 uncertainty, computed from LP (11)."""
    n = inst.n
    s = row_dual_norms_for_l1(inst.S)
    # variables are [p, epsilon], objective maximize epsilon = minimize -epsilon
    obj = np.r_[np.zeros(n), -1.0]
    # (I - A.T) p + epsilon * s <= cbar
    A_ub = np.c_[np.eye(n) - inst.A.T, s]
    b_ub = inst.cbar.copy()
    bounds = [(0.0, float(inst.pbar[i])) for i in range(n)] + [(0.0, None)]
    res = linprog(obj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(f"epsilon_ub LP failed for {inst.name}: {res.message}")
    return float(res.x[-1])


def robust_dual_l1_longonly(inst: FinancialNetworkInstance, epsilon: float) -> RobustDualResult:
    """Exact pre-insolvency robust loss for long-only l1 uncertainty.

    For S >= 0, the adverse l1 directions are single-asset price declines.  This
    function solves the robust dual LP once for each asset and returns the best
    value.  It is exact for epsilon <= epsilon_ub.
    """
    n, m = inst.n, inst.m
    total = inst.total_liabilities
    best = None
    B_ub = -np.c_[np.eye(n), np.eye(n) - inst.A]
    b_ub = -np.ones(n)
    bounds = [(0.0, None)] * (2 * n)
    for j in range(m):
        # minimize pbar^T beta + (cbar - eps*S_j)^T lambda; value = total - min
        obj = np.r_[inst.pbar, inst.cbar - float(epsilon) * inst.S[:, j]]
        res = linprog(obj, A_ub=B_ub, b_ub=b_ub, bounds=bounds, method="highs")
        if not res.success:
            candidate = RobustDualResult(
                value=-np.inf,
                value_norm=-np.inf,
                asset=j,
                epsilon=epsilon,
                pbar_total=total,
                beta=np.zeros(n),
                lam=np.zeros(n),
                success=False,
                message=res.message,
            )
        else:
            val = total - float(res.fun)
            candidate = RobustDualResult(
                value=val,
                value_norm=val / total,
                asset=j,
                epsilon=epsilon,
                pbar_total=total,
                beta=np.asarray(res.x[:n]),
                lam=np.asarray(res.x[n:]),
                success=True,
                message=res.message,
            )
        if best is None or candidate.value > best.value:
            best = candidate
    assert best is not None
    return best
