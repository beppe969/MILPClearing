from __future__ import annotations

from pathlib import Path

import pandas as pd


def csv_to_latex_table(csv_path: str | Path, tex_path: str | Path, columns=None, float_format: str = "%.4g") -> None:
    """Small helper used by the reproduction scripts to export reference CSV tables."""
    df = pd.read_csv(csv_path)
    if columns is not None:
        df = df[columns]
    Path(tex_path).parent.mkdir(parents=True, exist_ok=True)
    with open(tex_path, "w", encoding="utf-8") as f:
        f.write(df.to_latex(index=False, escape=False, float_format=lambda x: float_format % x))


def rebuild_simple_tex_tables(results_dir: str | Path = "results") -> None:
    """Regenerate generic LaTeX tables from the distributed CSV files.

    The paper-specific TeX files in ``results/tables`` are retained for exact
    manuscript formatting. This routine is useful when modifying CSV outputs.
    """
    results_dir = Path(results_dir)
    table_dir = results_dir / "tables"
    mapping = {
        "instance_summary.csv": "instance_summary_auto.tex",
        "validation_table.csv": "validation_table_auto.tex",
        "breakpoint_table.csv": "breakpoint_table_auto.tex",
        "bounds_table.csv": "bounds_table_auto.tex",
        "localized_bounds_table.csv": "localized_bounds_table_auto.tex",
        "localized_complexity_table.csv": "localized_complexity_table_auto.tex",
        "large_scenario_table.csv": "large_scenario_table_auto.tex",
        "large_localized_bounds_table.csv": "large_localized_bounds_table_auto.tex",
        "post_slope_decreases.csv": "post_slope_decreases_auto.tex",
        "salient_growth.csv": "salient_growth_auto.tex",
    }
    for csv_name, tex_name in mapping.items():
        path = table_dir / csv_name
        if path.exists():
            csv_to_latex_table(path, table_dir / tex_name)
