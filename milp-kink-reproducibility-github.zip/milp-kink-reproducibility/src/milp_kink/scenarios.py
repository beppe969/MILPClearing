from __future__ import annotations

from typing import Iterable, Optional

import numpy as np


def l1_boundary_random(m: int, epsilon: float, n: int, seed: int = 0, signed: bool = True) -> np.ndarray:
    """Random points on the l1 boundary using normalized Gaussian directions."""
    rng = np.random.default_rng(seed)
    g = rng.normal(size=(n, m))
    if not signed:
        g = np.abs(g)
    denom = np.sum(np.abs(g), axis=1, keepdims=True)
    return epsilon * g / denom


def long_only_l1_adverse_scenarios(
    m: int,
    epsilon: float,
    n_dirichlet: int = 1500,
    seed: int = 20250622,
    include_zero: bool = True,
) -> np.ndarray:
    """Scenarios for long-only l1 tests: delta = -epsilon*w, w>=0, 1'w<=1.

    The default construction reproduces the 1536-scenario design used for the
    M-bound tables: zero, vertices, three pairwise edge points per pair, and 1500
    Dirichlet boundary samples.
    """
    points = []
    if include_zero:
        points.append(np.zeros(m))
    for j in range(m):
        e = np.zeros(m)
        e[j] = 1.0
        points.append(e)
    for i in range(m):
        for j in range(i + 1, m):
            for t in (0.25, 0.50, 0.75):
                w = np.zeros(m)
                w[i] = t
                w[j] = 1.0 - t
                points.append(w)
    if n_dirichlet:
        rng = np.random.default_rng(seed)
        # Use a few concentrations to sample both sparse and diffuse directions.
        alphas = [0.15, 0.40, 1.0, 2.5, 8.0]
        counts = [n_dirichlet // len(alphas)] * len(alphas)
        counts[-1] += n_dirichlet - sum(counts)
        for alpha, count in zip(alphas, counts):
            points.extend(rng.dirichlet(np.full(m, alpha), size=count))
    W = np.vstack(points)
    return -float(epsilon) * W


def large_network_scenarios(
    m: int,
    epsilon: float,
    seed: int = 353,
    n_random: int = 35,
    heuristic: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Scenario set used for the L-353 lower-bound experiment.

    It contains the zero shock, single-asset price declines, random boundary
    scenarios and one optional heuristic direction.
    """
    points = [np.zeros(m)]
    for j in range(m):
        e = np.zeros(m)
        e[j] = 1.0
        points.append(e)
    rng = np.random.default_rng(seed)
    points.extend(rng.dirichlet(np.ones(m), size=n_random))
    if heuristic is None:
        heuristic = np.ones(m) / m
    heuristic = np.asarray(heuristic, dtype=float).reshape(m)
    heuristic = np.maximum(heuristic, 0.0)
    if heuristic.sum() <= 0:
        heuristic = np.ones(m) / m
    else:
        heuristic = heuristic / heuristic.sum()
    points.append(heuristic)
    W = np.vstack(points)
    return -float(epsilon) * W
