"""Reproducibility code for the MILP clearing / robust loss paper.

The package contains small, dependency-light routines for loading the fixed
instances, computing clearing vectors, solving the LP/MILP oracles, and
rebuilding the numerical figures and tables distributed with the paper.
"""

from .instances import FinancialNetworkInstance, load_instance, list_instances
from .clearing import (
    clearing_iteration,
    clearing_lp,
    clearing_milp,
    fixed_pattern_lp,
    loss,
    pattern_string,
)
from .robust import epsilon_star, epsilon_ub_l1, robust_dual_l1_longonly

__all__ = [
    "FinancialNetworkInstance",
    "load_instance",
    "list_instances",
    "clearing_iteration",
    "clearing_lp",
    "clearing_milp",
    "fixed_pattern_lp",
    "loss",
    "pattern_string",
    "epsilon_star",
    "epsilon_ub_l1",
    "robust_dual_l1_longonly",
]
