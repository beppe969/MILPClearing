from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np

from .clearing import clearing_iteration, fixed_pattern_lp, loss, pattern_string
from .instances import FinancialNetworkInstance


@dataclass
class ScenarioLowerBound:
    value: float
    value_norm: float
    best_index: int
    best_delta: np.ndarray
    best_pattern: str
    max_residual_inf: float
    distinct_patterns: int


@dataclass
class FixedPatternUpperBound:
    value: float
    value_norm: float
    pattern: str
    finite_patterns: int


def scenario_lower_bound(inst: FinancialNetworkInstance, deltas: np.ndarray, tol: float = 1e-10) -> ScenarioLowerBound:
    """Evaluate exact clearing on a finite scenario set and return the best loss."""
    best_value = -np.inf
    best_index = -1
    best_pattern = ""
    max_resid = 0.0
    patterns = set()
    for k, delta in enumerate(np.asarray(deltas, dtype=float)):
        res = clearing_iteration(inst.c(delta), inst.A, inst.pbar, tol=tol)
        val = res.loss
        max_resid = max(max_resid, res.residual_inf)
        patterns.add(res.pattern)
        if val > best_value:
            best_value = val
            best_index = k
            best_pattern = res.pattern
    return ScenarioLowerBound(
        value=best_value,
        value_norm=best_value / inst.total_liabilities,
        best_index=best_index,
        best_delta=np.asarray(deltas[best_index], dtype=float),
        best_pattern=best_pattern,
        max_residual_inf=max_resid,
        distinct_patterns=len(patterns),
    )


def fixed_pattern_upper_bound_long_only_l1(
    inst: FinancialNetworkInstance,
    epsilon: float,
    patterns: Iterable[str],
) -> FixedPatternUpperBound:
    """Global fixed-pattern upper bound over the adverse long-only l1 simplex.

    For each candidate pattern, feasibility and loss are checked at the vertices
    ``0, -epsilon*e_j``. Convexity of the fixed-pattern value and monotonicity in
    c justify this vertex calculation for the long-only adverse simplex.
    """
    m = inst.m
    vertices = [np.zeros(m)]
    for j in range(m):
        d = np.zeros(m)
        d[j] = -float(epsilon)
        vertices.append(d)
    best_value = np.inf
    best_pattern = ""
    finite = 0
    for z in patterns:
        vals = []
        feasible = True
        for delta in vertices:
            lp = fixed_pattern_lp(z, inst.c(delta), inst.A, inst.pbar)
            if not lp.success:
                feasible = False
                break
            vals.append(lp.loss)
        if feasible:
            finite += 1
            val = float(max(vals))
            if val < best_value:
                best_value = val
                best_pattern = z
    if not np.isfinite(best_value):
        # The all-zero pattern is always valid and has loss total liabilities.
        best_value = inst.total_liabilities
        best_pattern = "0" * inst.n
        finite = max(finite, 1)
    return FixedPatternUpperBound(
        value=best_value,
        value_norm=best_value / inst.total_liabilities,
        pattern=best_pattern,
        finite_patterns=finite,
    )


def patterns_from_scenarios(inst: FinancialNetworkInstance, deltas: np.ndarray, tol: float = 1e-10) -> List[str]:
    """Collect realized positive-payment patterns from exact clearing scenarios."""
    out = []
    seen = set()
    for delta in deltas:
        pat = clearing_iteration(inst.c(delta), inst.A, inst.pbar, tol=tol).pattern
        if pat not in seen:
            out.append(pat)
            seen.add(pat)
    return out


def intersect_patterns(patterns: Sequence[str]) -> str:
    """Coordinatewise intersection of payment patterns."""
    if not patterns:
        raise ValueError("empty pattern list")
    chars = []
    for vals in zip(*patterns):
        chars.append("1" if all(v == "1" for v in vals) else "0")
    return "".join(chars)

@dataclass
class LocalizedCertificateResult:
    lb_value: float
    ub_value: float
    lb_norm: float
    ub_norm: float
    cells: int
    splits: int
    local_clearings: int
    fixed_pattern_lps: int
    realized_patterns: int
    trace: list[dict]


def _delta_from_x(epsilon: float, x: np.ndarray) -> np.ndarray:
    return -float(epsilon) * np.asarray(x, dtype=float)


def _cell_centroid(vertices: np.ndarray) -> np.ndarray:
    return np.mean(vertices, axis=0)


def _longest_edge_split(vertices: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    q = vertices.shape[0]
    best = (0, 1, -1.0)
    for i in range(q):
        for j in range(i + 1, q):
            d = float(np.linalg.norm(vertices[i] - vertices[j]))
            if d > best[2]:
                best = (i, j, d)
    i, j, _ = best
    mid = 0.5 * (vertices[i] + vertices[j])
    v1 = vertices.copy()
    v2 = vertices.copy()
    v1[i] = mid
    v2[j] = mid
    return v1, v2


def _candidate_patterns_for_cell(inst: FinancialNetworkInstance, epsilon: float, vertices: np.ndarray, inherited: Iterable[str]) -> tuple[list[str], int]:
    pts = list(vertices) + [_cell_centroid(vertices)]
    patterns = list(inherited)
    clearings = 0
    for x in pts:
        res = clearing_iteration(inst.c(_delta_from_x(epsilon, x)), inst.A, inst.pbar)
        patterns.append(res.pattern)
        clearings += 1
    # intersections often give conservative regimes valid across the cell
    unique = []
    seen = set()
    for p in patterns:
        if p not in seen:
            unique.append(p)
            seen.add(p)
    if unique:
        inter = intersect_patterns(unique)
        if inter not in seen:
            unique.append(inter)
    zero = "0" * inst.n
    if zero not in seen:
        unique.append(zero)
    return unique, clearings


def _evaluate_cell(inst: FinancialNetworkInstance, epsilon: float, vertices: np.ndarray, patterns: Sequence[str]) -> tuple[float, float, int, list[str]]:
    """Return cell lower value, upper value, LP count, finite patterns."""
    # lower: exact clearing at vertices and centroid
    lb = -np.inf
    for x in list(vertices) + [_cell_centroid(vertices)]:
        res = clearing_iteration(inst.c(_delta_from_x(epsilon, x)), inst.A, inst.pbar)
        lb = max(lb, res.loss)
    ub = np.inf
    lp_count = 0
    finite_patterns: list[str] = []
    for z in patterns:
        feasible = True
        vals = []
        for x in vertices:
            lp = fixed_pattern_lp(z, inst.c(_delta_from_x(epsilon, x)), inst.A, inst.pbar)
            lp_count += 1
            if not lp.success:
                feasible = False
                break
            vals.append(lp.loss)
        if feasible:
            finite_patterns.append(z)
            ub = min(ub, max(vals))
    if not np.isfinite(ub):
        ub = inst.total_liabilities
    return lb, ub, lp_count, finite_patterns


def localized_certificate_long_only_l1(
    inst: FinancialNetworkInstance,
    epsilon: float,
    max_splits: int = 60,
    gap_tol: float = 1e-8,
) -> LocalizedCertificateResult:
    """Adaptive localized fixed-pattern certificate over the adverse l1 simplex.

    This compact implementation follows Section 4.3.3: cells are simplexes in the
    exposure-weight space x (delta = -epsilon*x), candidate regimes are generated
    at vertices and centroids, and each candidate is certified at all vertices.
    """
    m = inst.m
    initial = np.vstack([np.zeros(m), np.eye(m)])
    cells = [{"vertices": initial, "patterns": ["0" * inst.n]}]
    trace: list[dict] = []
    local_clearings = 0
    fixed_lps = 0
    realized: set[str] = set()

    def refresh_cell(cell: dict) -> None:
        nonlocal local_clearings, fixed_lps, realized
        pats, nclr = _candidate_patterns_for_cell(inst, epsilon, cell["vertices"], cell.get("patterns", []))
        local_clearings += nclr
        realized.update(pats)
        lb, ub, nlp, finite = _evaluate_cell(inst, epsilon, cell["vertices"], pats)
        fixed_lps += nlp
        cell["patterns"] = finite if finite else ["0" * inst.n]
        cell["lb"] = lb
        cell["ub"] = ub

    refresh_cell(cells[0])
    for split in range(max_splits + 1):
        global_lb = max(c["lb"] for c in cells)
        global_ub = max(c["ub"] for c in cells)
        trace.append({
            "iteration": split,
            "num_cells": len(cells),
            "LB_norm": global_lb / inst.total_liabilities,
            "localized_UB_norm": global_ub / inst.total_liabilities,
            "localized_gap_norm": max(0.0, global_ub - global_lb) / inst.total_liabilities,
            "fixed_pattern_lp_evals": fixed_lps,
            "local_pattern_clearings": local_clearings,
        })
        if split == max_splits or global_ub - global_lb <= gap_tol * inst.total_liabilities:
            return LocalizedCertificateResult(
                lb_value=global_lb,
                ub_value=global_ub,
                lb_norm=global_lb / inst.total_liabilities,
                ub_norm=global_ub / inst.total_liabilities,
                cells=len(cells),
                splits=split,
                local_clearings=local_clearings,
                fixed_pattern_lps=fixed_lps,
                realized_patterns=len(realized),
                trace=trace,
            )
        idx = int(np.argmax([c["ub"] for c in cells]))
        parent = cells.pop(idx)
        v1, v2 = _longest_edge_split(parent["vertices"])
        child1 = {"vertices": v1, "patterns": parent["patterns"]}
        child2 = {"vertices": v2, "patterns": parent["patterns"]}
        refresh_cell(child1)
        refresh_cell(child2)
        cells.extend([child1, child2])
    raise RuntimeError("unreachable")
