from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp


@dataclass
class ClearingResult:
    p: np.ndarray
    loss: float
    residual_inf: float
    iterations: int = 0
    success: bool = True
    message: str = ""
    pattern: str = ""


@dataclass
class LPResult:
    success: bool
    p: Optional[np.ndarray]
    value: float
    loss: float
    status: int = 0
    message: str = ""


def clearing_map(c: np.ndarray, A: np.ndarray, pbar: np.ndarray, p: np.ndarray) -> np.ndarray:
    """The Eisenberg--Noe--Elsinger map T_c(p)."""
    return np.maximum(0.0, np.minimum(pbar, c + A.T @ p))


def loss(p: np.ndarray, pbar: np.ndarray) -> float:
    """Aggregate unpaid interbank liability, 1' (pbar - p)."""
    return float(np.sum(pbar) - np.sum(p))


def pattern_string(p: np.ndarray, tol: float = 1e-9) -> str:
    """Binary positive-payment pattern: 1 means p_i > tol, 0 means zero payment."""
    return "".join("1" if x > tol else "0" for x in np.asarray(p).reshape(-1))


def zero_pay_set(p: np.ndarray, tol: float = 1e-9, one_based: bool = True) -> str:
    """Human-readable set of zero-payment banks."""
    idx = np.where(np.asarray(p).reshape(-1) <= tol)[0]
    if one_based:
        idx = idx + 1
    if len(idx) == 0:
        return "none"
    return "{" + ",".join(str(int(i)) for i in idx) + "}"


def state_string(c: np.ndarray, A: np.ndarray, pbar: np.ndarray, p: np.ndarray, tol: float = 1e-8) -> str:
    """Classify each bank as F=full payment, Z=zero payment, R=resource-bound, P=positive slack.

    The state labels are used for diagnostics in the scalar post-insolvency example.
    """
    resources = c + A.T @ p
    out = []
    for pi, pbi, ri in zip(p, pbar, resources):
        if pi <= tol:
            out.append("Z")
        elif pi >= pbi - tol:
            out.append("F")
        elif abs(pi - ri) <= 1e-6:
            out.append("R")
        else:
            out.append("P")
    return "".join(out)


def clearing_iteration(
    c: np.ndarray,
    A: np.ndarray,
    pbar: np.ndarray,
    tol: float = 1e-10,
    max_iter: int = 200_000,
) -> ClearingResult:
    """Compute the maximal clearing vector by monotone iteration from pbar.

    The map is monotone and maps ``[0, pbar]`` into itself. Starting from ``pbar``
    gives a nonincreasing sequence converging to the greatest fixed point. This is
    the iterative procedure reported in Section 7.6 of the paper.
    """
    c = np.asarray(c, dtype=float).reshape(-1)
    A = np.asarray(A, dtype=float)
    pbar = np.asarray(pbar, dtype=float).reshape(-1)
    p = pbar.copy()
    residual = np.inf
    for k in range(1, max_iter + 1):
        p_next = clearing_map(c, A, pbar, p)
        residual = float(np.max(np.abs(p_next - p)))
        p = p_next
        if residual <= tol:
            break
    else:
        return ClearingResult(
            p=p,
            loss=loss(p, pbar),
            residual_inf=float(np.max(np.abs(clearing_map(c, A, pbar, p) - p))),
            iterations=max_iter,
            success=False,
            message="maximum number of iterations reached",
            pattern=pattern_string(p),
        )
    residual = float(np.max(np.abs(clearing_map(c, A, pbar, p) - p)))
    return ClearingResult(
        p=p,
        loss=loss(p, pbar),
        residual_inf=residual,
        iterations=k,
        success=True,
        pattern=pattern_string(p),
    )


def clearing_lp(c: np.ndarray, A: np.ndarray, pbar: np.ndarray, tol: float = 1e-9) -> LPResult:
    """Solve the fixed-shock clearing LP, valid when the LP is feasible.

    It solves ``max 1'p`` subject to ``0 <= p <= pbar`` and
    ``(I - A.T) p <= c``.
    """
    c = np.asarray(c, dtype=float).reshape(-1)
    n = c.size
    A_ub = np.eye(n) - np.asarray(A, dtype=float).T
    b_ub = c
    obj = -np.ones(n)
    bounds = [(0.0, float(pbar[i])) for i in range(n)]
    res = linprog(obj, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not res.success:
        return LPResult(False, None, -np.inf, np.inf, res.status, res.message)
    p = np.asarray(res.x)
    return LPResult(True, p, float(np.sum(p)), loss(p, pbar), res.status, res.message)


def clearing_milp(c: np.ndarray, A: np.ndarray, pbar: np.ndarray, time_limit: Optional[float] = None) -> ClearingResult:
    """Solve the exact MILP clearing formulation from Theorem 1.

    This is mainly used as an independent oracle in small/medium tests. For large
    long-only instances, monotone iteration is usually faster.
    """
    c = np.asarray(c, dtype=float).reshape(-1)
    pbar = np.asarray(pbar, dtype=float).reshape(-1)
    A = np.asarray(A, dtype=float)
    n = pbar.size
    M = np.maximum(-c, 0.0)
    # Variables are [p_1,...,p_n,z_1,...,z_n].  Minimize -1'p.
    obj = np.r_[-np.ones(n), np.zeros(n)]
    integrality = np.r_[np.zeros(n, dtype=int), np.ones(n, dtype=int)]
    lb = np.r_[np.zeros(n), np.zeros(n)]
    ub = np.r_[pbar, np.ones(n)]
    bounds = Bounds(lb, ub)

    rows = []
    lower = []
    upper = []
    # p_i - pbar_i z_i <= 0
    for i in range(n):
        row = np.zeros(2 * n)
        row[i] = 1.0
        row[n + i] = -pbar[i]
        rows.append(row)
        lower.append(-np.inf)
        upper.append(0.0)
    # (I - A.T) p + M_i z_i <= c_i + M_i
    B = np.eye(n) - A.T
    for i in range(n):
        row = np.zeros(2 * n)
        row[:n] = B[i]
        row[n + i] = M[i]
        rows.append(row)
        lower.append(-np.inf)
        upper.append(c[i] + M[i])
    constraints = LinearConstraint(np.vstack(rows), np.array(lower), np.array(upper))
    options = {}
    if time_limit is not None:
        options["time_limit"] = float(time_limit)
    res = milp(c=obj, constraints=constraints, bounds=bounds, integrality=integrality, options=options)
    if not res.success:
        p = np.full(n, np.nan)
        return ClearingResult(p=p, loss=np.inf, residual_inf=np.inf, success=False, message=res.message)
    p = np.asarray(res.x[:n])
    residual = float(np.max(np.abs(clearing_map(c, A, pbar, p) - p)))
    return ClearingResult(
        p=p,
        loss=loss(p, pbar),
        residual_inf=residual,
        success=True,
        message=res.message,
        pattern=pattern_string(p),
    )


def fixed_pattern_lp(z: Sequence[int] | str, c: np.ndarray, A: np.ndarray, pbar: np.ndarray) -> LPResult:
    """Solve the regime-restricted LP for a fixed binary payment pattern z.

    The LP is ``max 1'p`` subject to ``0 <= p <= diag(z) pbar`` and
    ``diag(z) (I - A.T) p <= diag(z) c``.
    """
    if isinstance(z, str):
        z_arr = np.array([int(ch) for ch in z], dtype=float)
    else:
        z_arr = np.asarray(z, dtype=float).reshape(-1)
    c = np.asarray(c, dtype=float).reshape(-1)
    pbar = np.asarray(pbar, dtype=float).reshape(-1)
    A = np.asarray(A, dtype=float)
    n = pbar.size
    if z_arr.size != n:
        raise ValueError("pattern length does not match pbar")
    bounds = [(0.0, float(z_arr[i] * pbar[i])) for i in range(n)]
    active = np.where(z_arr > 0.5)[0]
    if active.size:
        A_ub = (np.eye(n) - A.T)[active, :]
        b_ub = c[active]
    else:
        A_ub = None
        b_ub = None
    res = linprog(-np.ones(n), A_ub=A_ub, b_ub=b_ub, bounds=bounds, method="highs")
    if not res.success:
        return LPResult(False, None, -np.inf, np.inf, res.status, res.message)
    p = np.asarray(res.x)
    return LPResult(True, p, float(np.sum(p)), loss(p, pbar), res.status, res.message)
