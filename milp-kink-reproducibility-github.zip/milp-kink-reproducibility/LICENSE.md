This repository is provided as a reproducibility package for manuscript review.
No open-source license has been selected in this draft package.

Before public GitHub release, the authors should replace this placeholder with
the intended license terms.
