#!/usr/bin/env python3
"""Recompute scenario lower bounds for the 353-bank instance.

This is the scalable lower-bound experiment from Section 7.6.  Timing and the
best scenario may vary slightly with hardware and random seed, but the script
uses deterministic scenarios by default.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink import load_instance, epsilon_star, epsilon_ub_l1
from milp_kink.certificates import scenario_lower_bound
from milp_kink.scenarios import large_network_scenarios


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(ROOT / "results" / "tables" / "large_scenario_table_recomputed.csv"))
    parser.add_argument("--n-random", type=int, default=35)
    args = parser.parse_args()
    inst = load_instance("L-353", ROOT / "data")
    eps_ub = epsilon_ub_l1(inst)
    eps_star_over_ub = epsilon_star(inst) / eps_ub
    rows = []
    for ratio in [0.0, eps_star_over_ub, 0.5, 1.0, 1.5, 2.0, 3.0, 5.0]:
        eps = ratio * eps_ub
        deltas = large_network_scenarios(inst.m, eps, n_random=args.n_random)
        lb = scenario_lower_bound(inst, deltas)
        rows.append({
            "epsilon_over_ub": ratio,
            "epsilon": eps,
            "epsilon_star_over_ub": eps_star_over_ub,
            "best_LB_norm": lb.value_norm,
            "num_scenarios": len(deltas),
            "distinct_patterns": lb.distinct_patterns,
            "best_pattern": lb.best_pattern,
            "best_delta_norm": abs(lb.best_delta).sum(),
            "max_residual_inf": lb.max_residual_inf,
        })
        print(rows[-1])
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
