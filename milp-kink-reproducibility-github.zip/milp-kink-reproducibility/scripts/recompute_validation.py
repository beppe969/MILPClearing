#!/usr/bin/env python3
"""Recompute the random pointwise clearing validation table for D-val.

This script uses the fixed-shock clearing LP when feasible and monotone clearing
iteration as an independent exact oracle.  Timing columns vary by machine; the
loss and feasibility columns should be close to the reference table.
"""
from __future__ import annotations

import argparse
import time
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink import load_instance, epsilon_ub_l1, clearing_lp, clearing_iteration
from milp_kink.scenarios import l1_boundary_random


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=271828)
    parser.add_argument("--num-shocks", type=int, default=100)
    parser.add_argument("--out", default=str(ROOT / "results" / "tables" / "validation_table_recomputed.csv"))
    args = parser.parse_args()
    inst = load_instance("D-val", ROOT / "data")
    eps_ub = epsilon_ub_l1(inst)
    rows = []
    for ratio in [0.5, 1.0, 1.2, 2.0]:
        eps = ratio * eps_ub
        deltas = l1_boundary_random(inst.m, eps, args.num_shocks, seed=args.seed + int(1000 * ratio), signed=True)
        lp_losses = []
        exact_losses = []
        lp_times = []
        exact_times = []
        lp_gap = []
        insolvent = []
        residuals = []
        feasible_count = 0
        for delta in deltas:
            c = inst.c(delta)
            t0 = time.perf_counter()
            lp = clearing_lp(c, inst.A, inst.pbar)
            lp_times.append(time.perf_counter() - t0)
            t0 = time.perf_counter()
            ex = clearing_iteration(c, inst.A, inst.pbar)
            exact_times.append(time.perf_counter() - t0)
            exact_losses.append(ex.loss / inst.total_liabilities)
            residuals.append(ex.residual_inf)
            resources = c + inst.A.T @ ex.p
            insolvent.append(float(np.sum(resources < -1e-8)))
            if lp.success:
                feasible_count += 1
                lp_losses.append(lp.loss / inst.total_liabilities)
                lp_gap.append(abs((lp.loss - ex.loss) / inst.total_liabilities))
        rows.append({
            "epsilon_over_ub": ratio,
            "avg_LP_loss_norm": np.mean(lp_losses) if lp_losses else np.nan,
            "avg_exact_loss_norm": np.mean(exact_losses),
            "avg_insolvent_banks": np.mean(insolvent),
            "LP_feasible_fraction": feasible_count / args.num_shocks,
            "avg_LP_time_s": np.mean(lp_times),
            "avg_exact_time_s": np.mean(exact_times),
            "max_LP_exact_gap_norm": np.max(lp_gap) if lp_gap else np.nan,
            "max_residual_inf": np.max(residuals),
            "num_shocks": args.num_shocks,
        })
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
