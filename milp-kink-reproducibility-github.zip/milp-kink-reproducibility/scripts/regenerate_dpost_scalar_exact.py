"""Regenerate the D-post scalar post-insolvency curve and kink table.

This script replaces the previous grid-based scalar search by an exact
one-dimensional regime enumeration for the long-only single-asset D-post
instance.  It writes:
  * results/data/post_scalar_curve.csv
  * results/tables/post_slope_decreases.csv
  * results/tables/post_slope_decreases.tex
  * results/figures/post_insolvency_scalar_curve.{pdf,png}
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "D-post.npz"
OUT_DATA = ROOT / "results" / "data" / "post_scalar_curve.csv"
OUT_TABLE_CSV = ROOT / "results" / "tables" / "post_slope_decreases.csv"
OUT_TABLE_TEX = ROOT / "results" / "tables" / "post_slope_decreases.tex"
OUT_FIG_PDF = ROOT / "results" / "figures" / "post_insolvency_scalar_curve.pdf"
OUT_FIG_PNG = ROOT / "results" / "figures" / "post_insolvency_scalar_curve.png"

TOL = 1e-9


@dataclass(frozen=True)
class Candidate:
    states: tuple[int, ...]  # 0 = zero, 1 = full, 2 = resource-bound positive
    alpha: np.ndarray       # p(eps) = alpha + beta eps
    beta: np.ndarray
    lo: float
    hi: float

    @property
    def z(self) -> str:
        return "".join("0" if s == 0 else "1" for s in self.states)

    @property
    def state_label(self) -> str:
        return "".join("ZFR"[s] for s in self.states)

    @property
    def pay_intercept(self) -> float:
        return float(self.alpha.sum())

    @property
    def pay_slope(self) -> float:
        return float(self.beta.sum())

    def payment(self, eps: float) -> float:
        return self.pay_intercept + self.pay_slope * eps

    def p(self, eps: float) -> np.ndarray:
        return self.alpha + self.beta * eps


def impose_ge_interval(a: float, b: float, lo: float, hi: float) -> tuple[float, float] | None:
    """Return interval after imposing a + b eps >= 0."""
    if abs(b) < 1e-12:
        return (lo, hi) if a >= -1e-8 else None
    root = -a / b
    if b > 0:
        lo = max(lo, root)
    else:
        hi = min(hi, root)
    if hi < lo - 1e-8:
        return None
    return lo, hi


def enumerate_candidates(A: np.ndarray, pbar: np.ndarray, cbar: np.ndarray, S: np.ndarray) -> list[Candidate]:
    n = len(pbar)
    candidates: list[Candidate] = []
    for states in product([0, 1, 2], repeat=n):
        F = np.array([i for i, s in enumerate(states) if s == 1], dtype=int)
        R = np.array([i for i, s in enumerate(states) if s == 2], dtype=int)
        alpha = np.zeros(n)
        beta = np.zeros(n)
        alpha[F] = pbar[F]
        if len(R):
            M = np.eye(len(R)) - A.T[np.ix_(R, R)]
            rhs_alpha = cbar[R].copy()
            rhs_beta = -S[R].copy()
            if len(F):
                rhs_alpha += A.T[np.ix_(R, F)].dot(pbar[F])
            try:
                alpha[R] = np.linalg.solve(M, rhs_alpha)
                beta[R] = np.linalg.solve(M, rhs_beta)
            except np.linalg.LinAlgError:
                continue

        r_alpha = cbar + A.T.dot(alpha)
        r_beta = -S + A.T.dot(beta)
        lo, hi = 0.0, float("inf")
        feasible = True
        for i, state in enumerate(states):
            if state == 0:
                # zero-payment bank: resource must be nonpositive
                out = impose_ge_interval(-r_alpha[i], -r_beta[i], lo, hi)
            elif state == 1:
                # full-payment bank: resource must cover full payment
                out = impose_ge_interval(r_alpha[i] - pbar[i], r_beta[i], lo, hi)
            else:
                # resource-bound positive payment: 0 <= p_i <= pbar_i
                out = impose_ge_interval(alpha[i], beta[i], lo, hi)
                if out is not None:
                    lo, hi = out
                    out = impose_ge_interval(pbar[i] - alpha[i], -beta[i], lo, hi)
            if out is None:
                feasible = False
                break
            lo, hi = out
        if feasible:
            lo = max(0.0, lo)
            if hi >= lo - 1e-8:
                candidates.append(Candidate(tuple(states), alpha, beta, lo, hi))
    return candidates


def active_segments(candidates: list[Candidate], eps_max: float) -> list[tuple[float, float, Candidate]]:
    boundaries = {0.0, eps_max}
    for c in candidates:
        if c.hi < -TOL or c.lo > eps_max + TOL:
            continue
        boundaries.add(max(0.0, c.lo))
        if np.isfinite(c.hi):
            boundaries.add(min(eps_max, c.hi))
    pts = sorted(x for x in boundaries if -TOL <= x <= eps_max + TOL)
    raw: list[tuple[float, float, Candidate]] = []
    for a, b in zip(pts[:-1], pts[1:]):
        if b - a <= 1e-8:
            continue
        mid = 0.5 * (a + b)
        valid = [c for c in candidates if c.lo <= mid + 1e-8 and c.hi + 1e-8 >= mid]
        if not valid:
            continue
        best = max(valid, key=lambda c: c.payment(mid))
        raw.append((a, b, best))

    # Merge adjacent intervals with the same affine payment and z pattern.
    merged: list[tuple[float, float, Candidate]] = []
    for a, b, c in raw:
        if merged:
            a0, b0, c0 = merged[-1]
            same_line = abs(c0.pay_intercept - c.pay_intercept) < 1e-7 and abs(c0.pay_slope - c.pay_slope) < 1e-7
            if same_line and c0.z == c.z and abs(b0 - a) < 1e-7:
                merged[-1] = (a0, b, c0)
                continue
        merged.append((a, b, c))
    return merged


def zero_pay_set(z: str) -> str:
    banks = [str(i + 1) for i, val in enumerate(z) if val == "0"]
    return "none" if not banks else "{" + ",".join(banks) + "}"


def zero_pay_set_latex(z: str) -> str:
    banks = [str(i + 1) for i, val in enumerate(z) if val == "0"]
    return "none" if not banks else r"$\{" + ",".join(banks) + r"\}$"


def fmt_slope(x: float) -> str:
    if abs(x) < 5e-12:
        x = 0.0
    return f"{x:.3g}"


def main() -> None:
    inst = np.load(DATA_PATH)
    A = inst["A"]
    pbar = inst["pbar"]
    cbar = inst["cbar"]
    S = inst["S"].reshape(-1)
    total = float(pbar.sum())
    n = len(pbar)

    candidates = enumerate_candidates(A, pbar, cbar, S)
    all_positive = [c for c in candidates if c.z == "1" * n and np.isfinite(c.hi) and c.hi - c.lo > 1e-7]
    if not all_positive:
        raise RuntimeError("Could not infer epsilon_ub from all-positive regimes")
    eps_ub = max(c.hi for c in all_positive)
    full_state = tuple([1] * n)
    full_candidates = [c for c in candidates if c.states == full_state and np.isfinite(c.hi)]
    eps_star = full_candidates[0].hi if full_candidates else 0.0
    eps_max = 4.0 * eps_ub
    segments = active_segments(candidates, eps_max)

    # Dense curve plus all exact breakpoints.
    grid = np.linspace(0.0, eps_max, 500)
    breakpoints = sorted({a for a, _, _ in segments} | {b for _, b, _ in segments})
    xvals = np.array(sorted(set(np.round(np.r_[grid, breakpoints], 12))))
    rows = []
    for eps in xvals:
        seg = next((c for a, b, c in segments if a - 1e-8 <= eps <= b + 1e-8), segments[-1][2])
        p = seg.p(eps)
        loss = total - float(p.sum())
        rows.append({
            "epsilon": eps,
            "epsilon_over_ub": eps / eps_ub,
            "loss": loss,
            "loss_norm": loss / total,
            "delta_star": -eps,
            "pattern": seg.z,
            "state": seg.state_label,
            "residual_inf": 0.0,
        })
    pd.DataFrame(rows).to_csv(OUT_DATA, index=False)

    # Kink table for the post-insolvency region, using slopes in the same axes as Fig. 3.
    kink_rows = []
    for (a1, b1, c1), (a2, b2, c2) in zip(segments[:-1], segments[1:]):
        if abs(b1 - a2) > 1e-7:
            continue
        if a2 / eps_ub < 1.0 - 1e-7:
            continue
        left_slope = -c1.pay_slope * eps_ub / total
        right_slope = -c2.pay_slope * eps_ub / total
        if abs(left_slope - right_slope) < 1e-7 and c1.z == c2.z:
            continue
        kink_rows.append({
            "epsilon_over_ub": a2 / eps_ub,
            "slope_left_norm": left_slope,
            "slope_right_norm": right_slope,
            "pattern_left": c1.z,
            "pattern_right": c2.z,
            "state_left": c1.state_label,
            "state_right": c2.state_label,
            "zero_pay_left": zero_pay_set(c1.z),
            "zero_pay_right": zero_pay_set(c2.z),
        })
    kink_df = pd.DataFrame(kink_rows)
    kink_df.to_csv(OUT_TABLE_CSV, index=False)

    with OUT_TABLE_TEX.open("w") as f:
        f.write("\\begin{tabular}{ccccc}\n")
        f.write("\\toprule\n")
        f.write("\\rev{$\\epsilon/\\epsilon_{ub}$} & \\rev{left slope} & \\rev{right slope} & \\rev{left zero-pay} & \\rev{right zero-pay} \\\\\n")
        f.write("\\midrule\n")
        for _, r in kink_df.iterrows():
            f.write(
                "\\rev{" + f"{r['epsilon_over_ub']:.4g}" + "} & "
                "\\rev{" + fmt_slope(float(r['slope_left_norm'])) + "} & "
                "\\rev{" + fmt_slope(float(r['slope_right_norm'])) + "} & "
                "\\rev{" + zero_pay_set_latex(str(r['pattern_left'])) + "} & "
                "\\rev{" + zero_pay_set_latex(str(r['pattern_right'])) + "} " + r"\\" + "\n"
            )
        f.write("\\bottomrule\n")
        f.write("\\end{tabular}\n")

    # Figure.
    fig, ax = plt.subplots(figsize=(7.2, 4.0))
    curve = pd.read_csv(OUT_DATA)
    ax.plot(curve["epsilon_over_ub"], curve["loss_norm"], label="exact scalar endpoint")
    ax.axvline(eps_star / eps_ub, linestyle=":", linewidth=1.0, label=r"$\epsilon^*$")
    ax.axvline(1.0, linestyle="--", linewidth=1.0, label=r"$\epsilon_{ub}$")
    if not kink_df.empty:
        kx = kink_df["epsilon_over_ub"].to_numpy()
        ky = []
        for x in kx:
            eps = x * eps_ub
            seg = next(c for a, b, c in segments if a - 1e-8 <= eps <= b + 1e-8)
            ky.append((total - seg.payment(eps)) / total)
        ax.plot(kx, ky, "o", markersize=4, label="post-insolvency kinks")
    ax.set_xlabel(r"$\epsilon/\epsilon_{ub}$")
    ax.set_ylabel("normalized worst-case loss")
    ax.set_xlim(0, 4.0)
    ax.set_ylim(-0.02, 1.05)
    ax.grid(True, alpha=0.25)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    fig.savefig(OUT_FIG_PDF)
    fig.savefig(OUT_FIG_PNG, dpi=300)
    plt.close(fig)

    print(f"epsilon_star/epsilon_ub = {eps_star / eps_ub:.6g}")
    print(f"epsilon_ub = {eps_ub:.12g}")
    print(kink_df)


if __name__ == "__main__":
    main()
