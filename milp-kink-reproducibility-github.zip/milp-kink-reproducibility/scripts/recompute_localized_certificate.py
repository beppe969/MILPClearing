#!/usr/bin/env python3
"""Recompute a localized fixed-pattern certificate for a selected instance/radius.

Examples
--------
    python scripts/recompute_localized_certificate.py --instance M-bound --epsilon-over-ub 2 --splits 60
    python scripts/recompute_localized_certificate.py --instance L-353 --epsilon-over-ub 1.5 --splits 5

The implementation is intentionally transparent and may not reproduce the exact
paper timing counters, which depend on caching and implementation details, but it
uses the same cell-wise certificate idea from Section 4.3.3.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink import load_instance, epsilon_ub_l1
from milp_kink.certificates import localized_certificate_long_only_l1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--instance", choices=["M-bound", "L-353"], default="M-bound")
    parser.add_argument("--epsilon-over-ub", type=float, default=2.0)
    parser.add_argument("--splits", type=int, default=20)
    parser.add_argument("--out", default=None)
    args = parser.parse_args()

    inst = load_instance(args.instance, ROOT / "data")
    eps = args.epsilon_over_ub * epsilon_ub_l1(inst)
    res = localized_certificate_long_only_l1(inst, eps, max_splits=args.splits)
    print({
        "instance": args.instance,
        "epsilon_over_ub": args.epsilon_over_ub,
        "LB_norm": res.lb_norm,
        "localized_UB_norm": res.ub_norm,
        "cells": res.cells,
        "splits": res.splits,
        "local_clearings": res.local_clearings,
        "fixed_pattern_lps": res.fixed_pattern_lps,
        "realized_patterns": res.realized_patterns,
    })
    out = Path(args.out) if args.out else ROOT / "results" / "tables" / f"localized_certificate_{args.instance}_{args.epsilon_over_ub:g}_recomputed.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(res.trace).to_csv(out, index=False)
    print(f"Trace written to {out}")


if __name__ == "__main__":
    main()
