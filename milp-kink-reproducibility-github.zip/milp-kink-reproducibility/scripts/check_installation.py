#!/usr/bin/env python3
"""Lightweight reproducibility checks for the distributed instances."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink import load_instance, epsilon_star, epsilon_ub_l1, clearing_iteration, robust_dual_l1_longonly


def main() -> None:
    table = pd.read_csv(ROOT / "results" / "tables" / "instance_summary.csv")
    print("Checking l1 margins against Table 1/reference CSV...")
    for name in ["D-val", "D-pre", "M-bound", "D-post", "L-353"]:
        inst = load_instance(name, ROOT / "data")
        es = epsilon_star(inst)
        eu = epsilon_ub_l1(inst)
        row = table.loc[table["Instance"] == name].iloc[0]
        es_ref = float(row[r"$\epsilon^*$"])
        eu_ref = float(row[r"$\epsilon_{ub}$"])
        print(f"  {name:7s} eps*={es:.12g} (ref {es_ref:.12g}), eps_ub={eu:.12g} (ref {eu_ref:.12g})")
        if not (np.allclose(es, es_ref, rtol=2e-8, atol=2e-10) and np.allclose(eu, eu_ref, rtol=2e-8, atol=2e-10)):
            raise SystemExit(f"Margin check failed for {name}")
    print("\nChecking clearing iteration on one post-insolvency L-353 scenario...")
    inst = load_instance("L-353", ROOT / "data")
    eu = epsilon_ub_l1(inst)
    delta = np.zeros(inst.m)
    delta[0] = -2.0 * eu
    res = clearing_iteration(inst.c(delta), inst.A, inst.pbar)
    print(f"  loss_norm={res.loss/inst.total_liabilities:.6g}, residual={res.residual_inf:.3g}, iterations={res.iterations}, pattern_ones={res.pattern.count('1')}")
    if res.residual_inf > 1e-7:
        raise SystemExit("Clearing residual too large")
    print("\nChecking one robust LP-dual solve on D-pre at epsilon_ub...")
    inst = load_instance("D-pre", ROOT / "data")
    eu = epsilon_ub_l1(inst)
    dual = robust_dual_l1_longonly(inst, eu)
    print(f"  value_norm={dual.value_norm:.6g}, active direction={dual.q_label}, success={dual.success}")
    if not dual.success:
        raise SystemExit("Robust dual LP failed")
    print("\nAll lightweight checks passed.")


if __name__ == "__main__":
    main()
