#!/usr/bin/env python3
"""Recompute the pre-insolvency robust LP-dual curve for D-pre.

The active-line enumeration used for the manuscript is distributed as reference
CSV files.  This script provides an independent grid-based recomputation using
the robust dual LPs.  It writes results/data/pre_curve_recomputed.csv and is
useful for sanity checking the LP-duality implementation.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink import load_instance, epsilon_ub_l1, robust_dual_l1_longonly


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--points", type=int, default=241)
    parser.add_argument("--out", default=str(ROOT / "results" / "data" / "pre_curve_recomputed.csv"))
    args = parser.parse_args()
    inst = load_instance("D-pre", ROOT / "data")
    eps_ub = epsilon_ub_l1(inst)
    rows = []
    for eps in np.linspace(0.0, eps_ub, args.points):
        dual = robust_dual_l1_longonly(inst, eps)
        rows.append({
            "epsilon": eps,
            "epsilon_over_ub": eps / eps_ub,
            "loss": dual.value,
            "loss_norm": dual.value_norm,
            "q_label": dual.q_label,
            "success": dual.success,
        })
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
