#!/usr/bin/env python3
"""Recompute scenario lower bounds and simple global fixed-pattern UBs for M-bound.

The distributed reference results include the localized certificate used in the
paper.  This script recomputes the scenario lower bounds and a basic global
fixed-pattern bound from realized scenario regimes.  It is intentionally compact
and transparent; the reference CSVs are used for exact manuscript figures.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink import load_instance, epsilon_ub_l1
from milp_kink.certificates import scenario_lower_bound, patterns_from_scenarios, fixed_pattern_upper_bound_long_only_l1
from milp_kink.scenarios import long_only_l1_adverse_scenarios


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(ROOT / "results" / "tables" / "bounds_table_recomputed_basic.csv"))
    parser.add_argument("--n-dirichlet", type=int, default=1500)
    args = parser.parse_args()
    inst = load_instance("M-bound", ROOT / "data")
    eps_ub = epsilon_ub_l1(inst)
    rows = []
    for ratio in [0.8, 1.0, 1.2, 1.5, 2.0, 3.0]:
        eps = ratio * eps_ub
        deltas = long_only_l1_adverse_scenarios(inst.m, eps, n_dirichlet=args.n_dirichlet)
        lb = scenario_lower_bound(inst, deltas)
        patterns = ["0" * inst.n] + patterns_from_scenarios(inst, deltas)
        ub = fixed_pattern_upper_bound_long_only_l1(inst, eps, patterns)
        rows.append({
            "epsilon_over_ub": ratio,
            "LB_norm": lb.value_norm,
            "UB_norm_basic": ub.value_norm,
            "candidate_patterns": len(set(patterns)),
            "finite_patterns": ub.finite_patterns,
            "realized_patterns": lb.distinct_patterns,
            "best_pattern": lb.best_pattern,
            "max_residual_inf": lb.max_residual_inf,
        })
        print(rows[-1])
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
