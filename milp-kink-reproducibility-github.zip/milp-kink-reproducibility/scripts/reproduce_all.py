#!/usr/bin/env python3
"""Rebuild reference figures and optional auto-generated tables.

This script is the recommended first command after installing the repository:

    python scripts/reproduce_all.py

By default it reads the distributed reference CSV files and regenerates all paper
figures.  This is fast and deterministic.  Use --with-auto-tex to also create
simple *_auto.tex tables from the CSV files.  The manuscript-formatted tables are
already distributed in results/tables.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from milp_kink.plotting import plot_all
from milp_kink.tables import rebuild_simple_tex_tables


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", default=str(ROOT / "results"), help="Directory containing data/tables and receiving figures.")
    parser.add_argument("--figures-dir", default=None, help="Optional output directory for figures. Defaults to results/figures.")
    parser.add_argument("--with-auto-tex", action="store_true", help="Also generate generic *_auto.tex files from CSV tables.")
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    outdir = Path(args.figures_dir) if args.figures_dir else results_dir / "figures"
    plot_all(results_dir=results_dir, outdir=outdir)
    if args.with_auto_tex:
        rebuild_simple_tex_tables(results_dir=results_dir)
    print(f"Figures written to {outdir}")
    if args.with_auto_tex:
        print(f"Auto-generated TeX tables written to {results_dir / 'tables'}")


if __name__ == "__main__":
    main()
