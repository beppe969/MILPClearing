# Experiments

The reproducibility scripts are stored in `../scripts/` and the reusable code in
`../src/milp_kink/`.  This directory is intentionally left for additional local
experiments, notebooks, or variants that users may add after cloning the repository.
