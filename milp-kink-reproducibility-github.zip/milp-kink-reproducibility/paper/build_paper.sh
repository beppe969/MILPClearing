#!/usr/bin/env bash
# Build from repository root so that results/figures and results/tables paths resolve.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export TEXINPUTS="paper//:"
pdflatex paper/MILP_Kink_Springer_revised.tex
bibtex MILP_Kink_Springer_revised || true
pdflatex paper/MILP_Kink_Springer_revised.tex
pdflatex paper/MILP_Kink_Springer_revised.tex
